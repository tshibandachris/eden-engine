# Eden Engine (PWA)

Project package including frontend (Next.js + PWA) and backend (Express).

See instructions inside server/ and frontend/.
